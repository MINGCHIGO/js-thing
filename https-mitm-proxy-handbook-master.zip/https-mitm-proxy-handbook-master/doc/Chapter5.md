# 第五节：总结

随着苹果强推[ATS](https://developer.apple.com/news/?id=12212016b)和HTTP2的慢慢普及。对于互联网开发HTTPS已经变成了“日常”。  
HTTPS的核心就是证书链，证书链的“信任”核心是CA。  
对于普通用户来说，随意的安装一个证书可能就为以后的安全问题埋下了隐患。

## 一张图做个总结：
12306怎么想的？用http来传输一个CA根证书？是掩耳盗铃？还是CNNIC？  
<img src="img/Chapter5/12306.png" width="600px">  
